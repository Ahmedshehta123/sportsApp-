//
//  NetworkManager.swift
//  SwiftProject
//
//  Created by Ahmed on 20/06/2022.
//

import Foundation
import UIKit
class NetworkManager: ApiService {
    func fetchDataEvent(endpoint: String, completion: @escaping (([Event]?, Error?) -> Void)) {
        if let url3 = URL(string: UrlServices(endPoint: endpoint).urlForEvent){
            
            URLSession.shared.dataTask(with: url3) { data, response, error in
                if let data = data {
                    var arrayOfEvent = [Event]()
                    let decodedarray:Events? = convertFromJson(data: data)
                    arrayOfEvent = decodedarray?.events ?? []
                    completion(arrayOfEvent,nil)
                }
                if let error = error {
                    
                    completion(nil, error)

                }
            }.resume()
        }
//        if let  url3 = URL(string: UrlServices(endPoint: endpoint).url) {
//            URLSession.shared.dataTask(with: url3) { data, response, error in
//                if let data = data {
//                    var arrayOfEvent = [Event]()
//                    let decodedArray:Event? = convertFromJson(data: data)
//                    arrayOfEvent = decodedArray?.events ?? []
//                    //arrayOfEvent = decodedArray?.events ?? []
//                    completion(arrayOfEvent,nil)
//                }
//                if let error = error {
//
//                    completion(nil, error)
//
//                }
//            }.resume()
//        }
//
//
        
    }
    
//    func fetchUsersEvent(endpoint: String, completion: @escaping (([Events]?, Error?) -> Void)) {
//        <#code#>
//    }
    
//    func fetchUsersEvent(endpoint: String, completion: @escaping (([Event]?, Error?) -> Void)) {
//        if let url2 = URL(string: UrlServices(endPoint: endpoint).url) {
//            URLSession.shared.dataTask(with: url2) { data, response, error in
//                if let data = data {
//                  //  var arrayOfEvent = [Event]()
//                 //   let decodedArray:Events? = convertFromJson(data: data)
//               //     arrayOfEvent = decodedArray?.events ?? []
//                 //   completion(arrayOfEvent,nil)
//                }
//                if let error = error {
//
//                    completion(nil, error)
//
//                }
//            }.resume()
//        }
//
//
//}
//    func fetchUsersAction(endpoint: String, completion: @escaping (([Event]?, Error?) -> Void)) {
//
//    }
    
//    func fetchUsersLeg(endPoint: String, completion: @escaping (([League]?, Error?) -> Void)) {
//        <#code#>
//    }
    
    
  
    func fetchData(endPoint: String, completion: @escaping (([Sport]?, Error?) -> Void)) {
        // fetching data
        if let  url = URL(string: UrlServices(endPoint: endPoint).url) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let data = data {
                    var arrayOfSport = [Sport]()
                    let decodedArray:Sports? = convertFromJson(data: data)
                    arrayOfSport = decodedArray?.sports ?? []
                    completion(arrayOfSport,nil)
                }
                if let error = error {
                   
                    completion(nil, error)

                }
            }.resume()
        }

    }
    func fetchUsersLeg(endPoint:String,completion: @escaping (([League]?,Error?) ->Void)){
        if let urlLeg = URL(string: UrlServices(endPoint: endPoint).url){
            URLSession.shared.dataTask(with: urlLeg) {data , response , error in
                if let data = data{
                    var arrayOfLeague = [League]()
                    let decodedArray:Leagues? = convertFromJson(data: data)
                    arrayOfLeague = decodedArray?.countries ?? []
                    completion(arrayOfLeague,nil)
                }
                if let error = error {
                    
                    completion(nil, error)

                }
            }.resume()
        }
    }
//    func fetchUsersLeg(endPoint: String, completion: @escaping (([League]?, Error?) -> Void)) {
//        // fetching data
//        if let  url = URL(string: UrlServices(endPoint: endPoint).url) {
//            URLSession.sharedataTask(with: url) { data, response, error in
//                if let data = data {
//                    var arrayOfleague = [League()
//                    let decodedArray:League? = convertFromJson(data: data)
//                                         arrayOfleague = decodedArray?.?? []
//                    completion(arrayOfSport,nil)
//                }
//                if let error = error {
//
//                    completion(nil, error)
//
//                }
//            }.resume()
//        }
//
//    }
}

