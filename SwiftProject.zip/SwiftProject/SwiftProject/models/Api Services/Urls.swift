//
//  Urls.swift
//  SwiftProject
//
//  Created by Ahmed on 20/06/2022.
//

import Foundation
struct UrlServices {
    var endPoint: String = ""
    //var endpoint2:String = ""
    var urlForEvent : String{
        return "https://www.thesportsdb.com/api/v1/json/2/eventsseason.php?id=\(endPoint)"
    }
    var url: String {
        return "https://www.thesportsdb.com/api/v1/json/2/\(endPoint)"
    }

}
