//
//  ApiServices.swift
//  SwiftProject
//
//  Created by Ahmed on 20/06/2022.
//

import Foundation
protocol ApiService {
    func fetchData(endPoint: String, completion: @escaping (([Sport]?, Error?) -> Void))
    func fetchUsersLeg(endPoint: String, completion: @escaping (([League]?, Error?) -> Void))
   func fetchDataEvent(endpoint:String,completion: @escaping (([Event]?,Error?)-> Void))

//    func fetchUsers(endPoint2: Int, completion: @escaping (([User]?, Error?) -> Void))
}
