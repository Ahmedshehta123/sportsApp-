//
//  League.swift
//  SwiftProject
//
//  Created by Ahmed on 20/06/2022.
//

import Foundation
struct Leagues: Codable {
    let countries: [League]
}

// MARK: - League
struct League: Codable {
    let idLeague, strLeague, strSport,strYoutube,strBadge,intHomeScore,intAwayScore,strHomeTeam,strAwayTeam: String
    let strLeagueAlternate: String?
    
}
