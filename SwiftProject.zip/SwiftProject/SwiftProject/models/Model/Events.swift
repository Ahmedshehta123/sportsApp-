//
//  Events.swift
//  SwiftProject
//
//  Created by Ahmed on 22/06/2022.
//

import Foundation
struct Events:Codable{
    
let events: [Event]
}
// MARK: - Event
struct Event: Codable {
    
    let strEvent:String?
    let strLeague , strTime, dateEvent,intHomeScore,intAwayScore:String?
    
}
