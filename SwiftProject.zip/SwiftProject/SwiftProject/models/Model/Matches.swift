//
//  Matches.swift
//  SwiftProject
//
//  Created by Ahmed on 22/06/2022.
//

import Foundation
struct Welcome: Codable {
    let events: [Event]
}

// MARK: - Event
struct Event: Codable {
    let idEvent, idSoccerXML: String
    let idAPIfootball: JSONNull?
    let strEvent, strEventAlternate, strFilename: String
    let strSport: StrSport
    let idLeague: String
    let strLeague: StrLeague
    let strSeason: StrSeason
    let strDescriptionEN: JSONNull?
    let strHomeTeam, strAwayTeam, intHomeScore, intRound: String
    let intAwayScore, intSpectators: String
    let strOfficial, strTimestamp: JSONNull?
    let dateEvent: String
    let dateEventLocal: JSONNull?
    let strTime: String
    let strTimeLocal, strTVStation: JSONNull?
    let idHomeTeam, idAwayTeam: String
    let intScore, intScoreVotes, strResult, strVenue: JSONNull?
    let strCountry, strCity, strPoster, strSquare: JSONNull?
    let strFanart, strThumb, strBanner, strMap: JSONNull?
    let strTweet1, strTweet2, strTweet3, strVideo: JSONNull?
    let strStatus: JSONNull?
    let strPostponed: StrPostponed
    let strLocked: StrLocked
}

enum StrLeague: String, Codable {
    case englishPremierLeague = "English Premier League"
}

enum StrLocked: String, Codable {
    case unlocked = "unlocked"
}

enum StrPostponed: String, Codable {
    case no = "no"
}

enum StrSeason: String, Codable {
    case the20142015 = "2014-2015"
}

enum StrSport: String, Codable {
    case soccer = "Soccer"
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}
