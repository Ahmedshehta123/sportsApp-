//
//  ViewModel.swift
//  SwiftProject
//
//  Created by Ahmed on 20/06/2022.
//

import Foundation
class HomeViewModel {
    var sportArrEvent:[Event]?{
        didSet{
            bindingDataEvent(sportArrEvent,nil)

        }
    }

    var legErrorEvent:Error?{

        didSet{
            bindingDataEvent(nil,error)
        }

    }

    var sportArrLeg:[League]?{
        didSet{
            bindingDataLeg(sportArrLeg,nil)
            
        }
    }
    
    var legError:Error?{
        
        didSet{
            bindingDataLeg(nil,error)
        }
        
    }
    var sportsArray: [Sport]? {
        didSet {
            bindingData(sportsArray,nil)
        }
    }
    var error: Error? {
        didSet {
            bindingData(nil, error)
        }
    }
    let apiService: ApiService
    var bindingDataLeg: (([League]?,Error?) -> Void) = {_, _ in }
    var bindingData: (([Sport]?,Error?) -> Void) = {_, _ in }
    var bindingDataEvent: (([Event]?,Error?)->Void) = {_,_ in  }
    init(apiService: ApiService = NetworkManager()) {
        self.apiService = apiService
    }
    
    
    func fetchData(endPoint: String) {
        apiService.fetchData(endPoint: endPoint) { sports, error in
            if let sports = sports {
                self.sportsArray = sports
            }
            if let error = error {
                self.error = error
            }
        }
    }
 
    func fetchDataLeague(endPoint: String) {
        apiService.fetchUsersLeg(endPoint: endPoint) { league, error in
            if let league = league {
                self.sportArrLeg = league
            }
            if let error = error {
                self.error = error
            }
        }
    }

    func fetchDataEvent(endPoint:String){

        apiService.fetchDataEvent(endpoint: endPoint) { event, error in
            if let event = event {
                self.sportArrEvent = event
            }
            if let error = error {
                self.error = error
            }
        }
    }

}
