//
//  LegAction.swift
//  SwiftProject
//
//  Created by Ahmed on 21/06/2022.
//

import UIKit

class LegAction: UIViewController {
   var arrayOfEvent:[Event] = []
   var sportsArray:[Event] = []
    var matchResualt:String?
    var idLeague:String?
    @IBOutlet weak var collectionV1: UICollectionView!
    
    @IBOutlet weak var collectionV2: UICollectionView!
    @IBOutlet weak var collectionV3: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionV1.dataSource = self
        collectionV1.delegate = self
        //print(matchResualt)
        let homeViewModel3 = HomeViewModel()
        homeViewModel3.fetchDataEvent(endPoint: idLeague!)
        homeViewModel3.bindingDataEvent = { event,error in
            
            
            if let events = event{
                self.arrayOfEvent = events
          //      print("tmaam")
                DispatchQueue.main.async {
                    self.collectionV1.reloadData()
            }
                  }

            for i in 0..<self.arrayOfEvent.count{
                  // print(" \n\n nameleague\(self.arrayOfLeague[i].strLeague)\n\n")
                  // leagueNAme = arrayOfLeague[i].strLeague
                   if self.matchResualt == self.arrayOfEvent[i].strEvent{
                      // let nameOfSport = self.arrayOfLeague[i].strLeague
                       print("\n\n events is \(self.arrayOfEvent[i])\n\n")
                       self.sportsArray.append(self.arrayOfEvent[i])
                      
                      
                       DispatchQueue.main.async {
                              self.collectionV1.reloadData()
                       }
                       
                     //self.LeagueTV.reloadData()
                   }else{print("\n\n leagueName\(self.arrayOfEvent)")}
               
                }
                    
                        
            }

        
            
            
            
        }
        
//
        
        
   }
    


    
    
    
    


extension LegAction:UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == collectionV1{

            return arrayOfEvent.count
        }
        return arrayOfEvent.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        if collectionView == collectionV1 {
//
//            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "eventcell1", for: indexPath)as! EventCollectionV1
//            cell.lbl1.text = arrayOfEvent[indexPath.row].strEvent
//            return cell
//
//        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "eventcell1", for: indexPath)as! EventCollectionV1
        cell.lbl1.text = arrayOfEvent[indexPath.row].strEvent
        cell.dateLbl.text = arrayOfEvent[indexPath.row].dateEvent
        cell.timeLbl.text = arrayOfEvent[indexPath.row].strTime
        return cell
         
    }



}
