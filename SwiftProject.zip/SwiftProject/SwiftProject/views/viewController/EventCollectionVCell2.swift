//
//  EventCollectionVCell2.swift
//  SwiftProject
//
//  Created by Ahmed on 23/06/2022.
//

import UIKit

class EventCollectionVCell2: UICollectionViewCell {
    
}
