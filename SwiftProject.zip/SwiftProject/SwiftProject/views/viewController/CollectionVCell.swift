//
//  CollectionVCell.swift
//  SwiftProject
//
//  Created by Ahmed on 20/06/2022.
//

import UIKit

class CollectionVCell: UICollectionViewCell {
    
    @IBOutlet weak var ImgOfSport: UIImageView!
    
    @IBOutlet weak var NameOfSport: UILabel!
}
