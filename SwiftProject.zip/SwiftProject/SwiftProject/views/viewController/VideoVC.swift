//
//  VideoVC.swift
//  SwiftProject
//
//  Created by Ahmed on 23/06/2022.
//

import UIKit
import WebKit

class VideoVC: UIViewController {
    var urlLink:String = "https://www.youtube.com/results?search_query=sports+news+live"
    override func viewDidLoad() {
        super.viewDidLoad()
        webV.load(URLRequest(url: NSURL(string: urlLink)! as URL)as URLRequest)
        // Do any additional setup after loading the view.
    }
    

    @IBOutlet weak var webV: WKWebView!
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
