//
//  EventCollectionV1.swift
//  SwiftProject
//
//  Created by Ahmed on 22/06/2022.
//

import UIKit

class EventCollectionV1: UICollectionViewCell {
    @IBOutlet weak var lbl1: UILabel!
    
    @IBOutlet weak var dateLbl: UILabel!

    @IBOutlet weak var timeLbl: UILabel!
    
}
