//
//  LeguesVC.swift
//  SwiftProject
//
//  Created by Ahmed on 20/06/2022.
//

import UIKit

class LeguesVC: UIViewController {
    var arrayOfLeague:[League] = []
  //  var sportImage:[League] = []
    var imgOfLeague :String = ""
    var leagueNAme:String = ""
   
    
    @IBOutlet weak var LeagueTV: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        LeagueTV.delegate = self
        LeagueTV.dataSource = self
    print(leagueNAme)
        let homeViewModel1 = HomeViewModel()
        homeViewModel1.fetchDataLeague(endPoint: "search_all_leagues.php?s=\(leagueNAme)")
        homeViewModel1.bindingDataLeg = { League,error in
            
//
            if let leagues = League{
                self.arrayOfLeague = leagues
          //      print("tmaam")
                DispatchQueue.main.async {
                    self.LeagueTV.reloadData()
            }
                  }
//
//               for i in 0..<arrayOfLeague.count{
//                  // print(" \n\n nameleague\(self.arrayOfLeague[i].strLeague)\n\n")
//                  // leagueNAme = arrayOfLeague[i].strLeague
//                   if self.leagueNAme == self.arrayOfLeague[i].strSport{
//                      // let nameOfSport = self.arrayOfLeague[i].strLeague
//
//                        self.sportLeagues.append(arrayOfLeague[i])
//
//
//                       DispatchQueue.main.async {
//                              self.LeagueTV.reloadData()
//                       }
//
//                     //self.LeagueTV.reloadData()
//                   }else{print("\n\n leagueName\(sportLeagues)")}
//
//                }
                    
     
            }

            
     
    }

//    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        let videoVc = segue.destination as! VideoVC
//        let selectedRow = LeagueTV.indexPathForSelectedRow?.row
//       // videoVc.urlLink = arrayOfLeague[selectedRow!].
//    }
      

    @IBAction func btnLeg(_ sender: Any) {
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "LegAction")as! LegAction
        self.present(vc, animated: true, completion: nil)
        
        //
    }
    
    }
    

    


extension LeguesVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfLeague.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "legCell", for: indexPath)as! LeaguesTVCell
      //  cell.leagueName.text = arrayOfLeague[indexPath.row].strLeague
        cell.leagueName.text = arrayOfLeague[indexPath.row].strLeague
        cell.leagueIcon.sd_setImage(with: URL(string:arrayOfLeague[indexPath.row].strBadge ), placeholderImage: UIImage(named: "R2.png"))
        
      //  cell.leagueName.text = sportLeagues[indexPath.row]
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let eventVC = self.storyboard?.instantiateViewController(withIdentifier: "LegAction") as? LegAction {

           // self.navigationController?.pushViewController(leaguesVC, animated: true)
            eventVC.idLeague = arrayOfLeague[indexPath.row].idLeague
            eventVC.matchResualt = arrayOfLeague[indexPath.row].strLeague
            
            self.present(eventVC, animated: true, completion: nil)
            
        }
        
        //let leg = arrayOfLeague[indexPath.row]
    }
    
    
}

