//
//  ViewController.swift
//  SwiftProject
//
//  Created by Ahmed on 20/06/2022.
//

import UIKit
import SDWebImage

class ViewController: UIViewController {
    @IBOutlet weak var collection: UICollectionView!
    var ArraySports:[Sport] = []
    //var arr = ["a","s","d","d","f"]
   
    override func viewDidLoad() {
        super.viewDidLoad()
        collection.delegate = self
        collection.dataSource = self
        
        let homeViewModel = HomeViewModel()
          homeViewModel.fetchData(endPoint: "all_sports.php")
        
          homeViewModel.bindingData = { sports, error in
              if let sports = sports {
                  self.ArraySports = sports
                  DispatchQueue.main.async {
                      self.collection.reloadData()
                  }
              }
              if let error = error {
                  print(error.localizedDescription)
              }
          }
    
        // Do any additional setup after loading the view.
    }


    
}

extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
       // return ArraySports.count
        return ArraySports.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionVCell
//       // cell.ImgOfSport.image = ArraySports[indexPath.row].strSportIconGreen
//        cell.NameOfSport.text = ArraySports[indexPath.row].strSport
//        return cell
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionVCell
        cell.ImgOfSport.sd_setImage(with: URL(string:ArraySports[indexPath.row].strSportThumb ), placeholderImage: UIImage(named: "R2.png"))


        cell.NameOfSport.text = ArraySports[indexPath.row].strSport
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //var vc = storyboard?.instantiateViewController(withIdentifier: "LeguesVC")as! LeguesVC
        //self.navigationController?.pushViewController(vc, animated: true)
        
      //  vc.leagueNAme = ArraySports[indexPath.row].strSport
        
        if let leaguesVC = self.storyboard?.instantiateViewController(withIdentifier: "LeguesVC") as? LeguesVC {

           // self.navigationController?.pushViewController(leaguesVC, animated: true)
            
            leaguesVC.leagueNAme = ArraySports[indexPath.row].strSport
            leaguesVC.imgOfLeague = ArraySports[indexPath.row].strSportThumb
            self.present(leaguesVC, animated: true, completion: nil)
            
        }
       //
        //let sportt = ArraySports[indexPath.row]
        
        //vc.imgOfLeague = ArraySports[indexPath.row].strSportIconGreen
        
        
      //  let movie = movie1[indexPath.row]
        
    }
    
    
    
}
